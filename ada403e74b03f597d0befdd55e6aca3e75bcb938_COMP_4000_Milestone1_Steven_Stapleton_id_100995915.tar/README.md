Task 2: To demonstrate task 2. Run "node client && node server". Please note you may need to run npm rebuild.

Task 3: To demonstrate task 3. Run the same commands from Task 2 inside the folder named "Task 3".

Task 4: To demonstrate task 4. Run the same commands from Task 2. Note you may need to run "npm rebuild".

